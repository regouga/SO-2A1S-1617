/*
// Projeto SO - exercicio 2, version 1
// Sistemas Operativos, DEI/IST/ULisboa 2016-17

// Grupo 71
// Miguel Regouga, 83530
// Pedro Caldeira, 83539
*/

/*####################################################################################################################*/
/* BIBLIOTECAS 																										  */
/*####################################################################################################################*/

#include "commandlinereader.h"
#include "contas.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>



/*####################################################################################################################*/
/* COMANDOS 																										  */
/*####################################################################################################################*/

#define COMANDO_DEBITAR "debitar"
#define COMANDO_CREDITAR "creditar"
#define COMANDO_LER_SALDO "lerSaldo"
#define COMANDO_SIMULAR "simular"
#define COMANDO_SAIR "sair"
#define COMANDO_SAIR_AGORA "agora"
#define COMANDO_TRANSFERIR "transferir"



/*####################################################################################################################*/
/* CONSTANTES 																										  */
/*####################################################################################################################*/

#define MAXARGS 4
#define BUFFER_SIZE 100
#define STATUS_INFO_LINE_SIZE 50
#define NUM_PROC 20
#define NUM_CONTAS 10



/*####################################################################################################################*/
/* PROCESSOS 																										  */
/*####################################################################################################################*/

int proc[NUM_PROC];
int proc_count = 0;
int argumentos = 0;



/*####################################################################################################################*/
/* TAREFAS E VETOR CIRCULAR 																						  */
/*####################################################################################################################*/

#define COMANDO_DEBITAR_NUM 1
#define COMANDO_CREDITAR_NUM 2
#define COMANDO_LER_SALDO_NUM 3
#define COMANDO_SAIR_NUM 4
#define COMANDO_TRANSFERIR_NUM 5
#define COMANDO_SIMULAR_NUM 6

#define NUM_TRABALHADORAS 3
#define CMD_BUFFER_DIM (NUM_TRABALHADORAS * 2) 

typedef struct {
    int operacao;
    int idConta;
    int idConta2;
    int valor;
} comando_t;

comando_t cmd_buffer[CMD_BUFFER_DIM];
int buff_write_idx = 0, buff_read_idx = 0;



/*####################################################################################################################*/
/* SINCRONIZACAO (MUTEXS & SEMAFOROS)																				  */
/*####################################################################################################################*/

pthread_t tid[NUM_TRABALHADORAS+1];
pthread_mutex_t mutex;
pthread_mutex_t mutexSimular;

sem_t canRead;
sem_t canWrite;



/*####################################################################################################################*/
/* SINCRONIZACAO (VARIAVEIS DE CONDICAO)																			  */
/*####################################################################################################################*/

pthread_cond_t condWait2;
int vetorFlags[NUM_CONTAS];
int flagTarefasLeitoras = 0;



/*####################################################################################################################*/
/* FUNCAO SIMULARPROC (Criacao dos processos pai e filho - comando simular)											  */
/*####################################################################################################################*/

void simularProc(int numero_Anos) {

	int pid = fork();

	if (pid < 0) {
		perror("Erro no fork\n");
		exit(EXIT_FAILURE);
	}

	else if (pid > 0) { /* Codigo do processo pai */
		proc_count++;
	}

	else { /* Codigo do processo filho */
		simular(numero_Anos);
		exit(EXIT_SUCCESS);
	}
}

int contadorGlobal = 0; /* Incrementado quando e realizado algum dos comandos */
int contadorSimular = 0; /* Indice do comando simular */



/*####################################################################################################################*/
/* TAREFA ESCRITORA (Escreve no buffer circular)																	  */
/*####################################################################################################################*/

void tarefa_escritora(char *args[], comando_t buffer[]) {

    comando_t new;
    int idConta=0, valor=0, idConta1=0, idConta2=0;
    sem_wait(&canWrite);
    
    if (argumentos < 0 || (argumentos > 0 && (strcmp(args[0], COMANDO_SAIR) == 0))) {
        new.operacao = COMANDO_SAIR_NUM;
    }

    else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {
            
        idConta = atoi(args[1]);
        valor = atoi(args[2]);

        new.operacao = COMANDO_CREDITAR_NUM;
        new.idConta = idConta;
        new.valor = valor;

    }
        
    else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {

        idConta = atoi(args[1]);
        valor = atoi(args[2]);

        new.operacao = COMANDO_DEBITAR_NUM;
        new.idConta = idConta;
        new.valor = valor;
    }

    else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {

        idConta = atoi(args[1]);

        new.operacao = COMANDO_LER_SALDO_NUM;
        new.idConta = idConta;
        new.valor = 0;
    }
    
    else if (strcmp(args[0], COMANDO_TRANSFERIR) == 0) {

        idConta1 = atoi(args[1]);
        idConta2 = atoi(args[2]);
        valor = atoi(args[3]);

        new.operacao = COMANDO_TRANSFERIR_NUM;
        new.idConta = idConta1;
        new.idConta2 = idConta2;
        new.valor = valor;
    }

    else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {

    	valor = atoi(args[1]);

    	new.operacao = COMANDO_SIMULAR_NUM;
    	new.valor = valor;
    	contadorSimular = buff_write_idx;
    }
    
    else { 
        return;
    }
        
    cmd_buffer[buff_write_idx] = new;
    pthread_mutex_lock(&mutex);
    buff_write_idx = (buff_write_idx + 1) % CMD_BUFFER_DIM;
    pthread_mutex_unlock(&mutex);
    sem_post(&canRead);
    
}



/*####################################################################################################################*/
/* TAREFA LEITORA (Le os comandos do buffer circular)																  */
/*####################################################################################################################*/

void *tarefa_leitora() {

    comando_t atual;

    while (1) {
        
    	sem_wait(&canRead);
        pthread_mutex_lock(&mutex);
        atual = cmd_buffer[buff_read_idx];
        buff_read_idx = (buff_read_idx + 1) % CMD_BUFFER_DIM;
        pthread_mutex_unlock(&mutex);


        if (atual.operacao == 1) {


            if (debitar (atual.idConta, atual.valor) < 0)
               printf("%s(%d, %d): Erro\n\n", COMANDO_DEBITAR, atual.idConta, atual.valor);
            else {
            	printf("%s(%d, %d): OK\n\n", COMANDO_DEBITAR, atual.idConta, atual.valor);

            }

	   }

	    else if (atual.operacao == 2) {


	    	if (creditar (atual.idConta, atual.valor) < 0)
	    		printf("%s(%d, %d): Erro\n\n", COMANDO_CREDITAR, atual.idConta, atual.valor);

	    	else
	    		printf("%s(%d, %d): OK\n\n", COMANDO_CREDITAR, atual.idConta, atual.valor);

	   }
	        
        else if (atual.operacao == 3) {

            int saldo = lerSaldo(atual.idConta);

            if (saldo < 0)
                printf("%s(%d): Erro.\n\n", COMANDO_LER_SALDO, atual.idConta);
            else
                printf("%s(%d): O saldo da conta é %d.\n\n", COMANDO_LER_SALDO, atual.idConta, saldo);

	    }

	    
	    else if (atual.operacao == 4) {
            
            sem_post(&canWrite);
            pthread_exit(0);

        }

        
        else if (atual.operacao == 5) {

            if (transferir (atual.idConta, atual.idConta2, atual.valor) < 0)
                printf("Erro ao transferir %d da conta %d para a conta %d.\n\n", atual.valor, atual.idConta, atual.idConta2);
            else
                printf("%s(%d, %d, %d): OK\n\n", COMANDO_TRANSFERIR, atual.idConta, atual.idConta2, atual.valor);

        }


        else if (atual.operacao == 6) {

        	pthread_mutex_lock(&mutexSimular);

	   		while (contadorSimular != contadorGlobal) pthread_cond_wait(&condWait2, &mutexSimular);
	   		simularProc(atual.valor);

	   		pthread_mutex_unlock(&mutexSimular);

	   	}


	   	contadorGlobal = (contadorGlobal + 1) % CMD_BUFFER_DIM;

	   	if (contadorGlobal == contadorSimular ) {
	   		pthread_cond_broadcast(&condWait2);
	    	contadorSimular = 0;
	    	contadorGlobal = 0;
	    }

	    sem_post(&canWrite);
        
    }
}



/*####################################################################################################################*/
/* HANDLER (Trata o signal do simular)																				  */
/*####################################################################################################################*/

void handler(int sig) {
	if (sig == SIGUSR1)
	    atualiza(SIGUSR1);
}



/*####################################################################################################################*/
/* MAIN 																											  */
/*####################################################################################################################*/

int main (int argc, char** argv) {

    char *args[MAXARGS + 1];
    char buffer[BUFFER_SIZE];
    int i, j, k;

    inicializarContas();
    printf("Bem-vinda/o ao i-banco\n\n");
    signal(SIGUSR1, handler);
    sem_init(&canRead, 0, 0);
    sem_init(&canWrite, 0, 6);
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&mutexSimular, NULL);
    pthread_cond_init(&condWait2, NULL);


    for (i = 0; i < NUM_TRABALHADORAS; i++) {

        if (pthread_create(&tid[i], NULL, tarefa_leitora, NULL) != 0) {
            printf("Erro ao criar a tarefa.\n");
        }

        else {
            printf("Tarefa filha %d criada.\n", i+1);
        }
    }

    printf("\n");


    while (1) {

        int numargs;
        numargs = readLineArguments(args, MAXARGS+1, buffer, BUFFER_SIZE);
        argumentos = numargs;

        /* EOF (end of file) do stdin ou comando "sair" */
        if (numargs < 0 ||
            (numargs > 0 && (strcmp(args[0], COMANDO_SAIR) == 0))) {

            int status, childpid;
        
            for (k = 0; k < NUM_TRABALHADORAS; k++) tarefa_escritora(args, cmd_buffer);
            for (j = 0; j < NUM_TRABALHADORAS; j++) {
                pthread_join(tid[j], NULL);
            }

            printf("i-banco vai terminar.\n--\n");

            if (numargs == 2 && (strcmp(args[1], COMANDO_SAIR_AGORA) == 0)) {
                kill(0, SIGUSR1);
                printf("Simulacao terminada por signal\n");
            }

            while (proc_count > 0) {
                
                childpid = wait(&status);

                if (WIFEXITED(status)) {
                    printf("FILHO TERMINADO (PID=%d; terminou normalmente)\n", childpid);
                }
                
                else {
                    printf("FILHO TERMINADO (PID=%d; terminou abruptamente)\n", childpid);
                }

                proc_count --;
            }
            
            
            pthread_mutex_destroy(&mutex);
            pthread_mutex_destroy(&mutexSimular);
            pthread_cond_destroy(&condWait2);
            sem_destroy(&canRead);
            sem_destroy(&canWrite);
            printf("--\ni-banco terminou.\n");


            exit(EXIT_SUCCESS);
        }
    
        else if (numargs == 0)
            /* Nenhum argumento; ignora e volta a pedir */
            continue;
            
        /* Debitar */
        else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_DEBITAR);
               continue;
            }

            tarefa_escritora(args, cmd_buffer);

        }

        /* Creditar */
        else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_CREDITAR);
                continue;
            }

            tarefa_escritora(args, cmd_buffer);
        }

        /* Ler Saldo */
        else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {

            if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_LER_SALDO);
                continue;
            }

            tarefa_escritora(args, cmd_buffer);

        }
        
        /* Transferir */
        else if (strcmp(args[0], COMANDO_TRANSFERIR) == 0) {

            if (numargs < 4) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_TRANSFERIR);
                continue;
            }
            
            if (atoi(args[1]) == atoi(args[2])) {
                printf("%s: ID das contas igual, tente de novo.\n", COMANDO_TRANSFERIR);
                continue;
            }

            tarefa_escritora(args, cmd_buffer);

        }

        /* Simular */

        else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {

        	if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_SIMULAR);
                continue;
            }

        	tarefa_escritora(args, cmd_buffer); 

        }


        else {
          printf("Comando desconhecido. Tente de novo.\n");
        }

    } 
}
