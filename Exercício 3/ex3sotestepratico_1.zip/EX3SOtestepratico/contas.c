
#include "contas.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
 
#define atrasar() sleep(ATRASO)

pthread_mutex_t vetorMutex[NUM_CONTAS];
pthread_cond_t condWait;

int contasSaldos[NUM_CONTAS];
int cont_ano = 0, flag = 0;
int vetorFlags[NUM_CONTAS];

int contaExiste(int idConta) {
  return (idConta > 0 && idConta <= NUM_CONTAS);
}

void inicializarContas() {
  int i;
  for (i=0; i<NUM_CONTAS; i++)
    contasSaldos[i] = 0;
    pthread_mutex_init(&vetorMutex[i], 0);
}

int debitar(int idConta, int valor) {
    
    atrasar();
    
  if (!contaExiste(idConta)) {
    return -1;
  }
  pthread_mutex_lock(&vetorMutex[idConta-1]);
  while (vetorFlags[idConta-1] == 1) pthread_cond_wait(&condWait, &vetorMutex[idConta-1]);
  if (contasSaldos[idConta - 1] < valor) {
    pthread_mutex_unlock(&vetorMutex[idConta-1]);
    return -1;
  }
  atrasar();
  contasSaldos[idConta - 1] -= valor;
  pthread_mutex_unlock(&vetorMutex[idConta-1]);
  return 0;
}

int creditar(int idConta, int valor) {
    
    atrasar();
    
  if (!contaExiste(idConta)) {
    return -1;
  }
  pthread_mutex_lock(&vetorMutex[idConta-1]);
  while (vetorFlags[idConta-1] == 1) pthread_cond_wait(&condWait, &vetorMutex[idConta-1]);
  contasSaldos[idConta - 1] += valor;
  pthread_mutex_unlock(&vetorMutex[idConta-1]);
  return 0;
}

int lerSaldo(int idConta) {
    atrasar();
  if (!contaExiste(idConta))
    return -1;
  
  pthread_mutex_lock(&vetorMutex[idConta-1]);
  while (vetorFlags[idConta-1] == 1) pthread_cond_wait(&condWait, &vetorMutex[idConta-1]);
  pthread_mutex_unlock(&vetorMutex[idConta-1]);
  return contasSaldos[idConta - 1];
}

int transferir(int idConta1, int idConta2, int valor) {
    
    vetorFlags[idConta1-1] = 1;
    vetorFlags[idConta2-1] = 1;
    atrasar();
    
    pthread_mutex_lock(&vetorMutex[idConta1-1]);
    pthread_mutex_lock(&vetorMutex[idConta2-1]);

  if (!contaExiste(idConta1) || !contaExiste(idConta2)) {
    return -1;
  }
  
  if (contasSaldos[idConta1 - 1] < valor) {
    return -1;
  }
  
  contasSaldos[idConta1 - 1] -= valor;
  contasSaldos[idConta2 - 1] += valor;
  
  pthread_mutex_unlock(&vetorMutex[idConta2-1]);
  pthread_mutex_unlock(&vetorMutex[idConta1-1]);
  
  pthread_cond_broadcast(&condWait);
  
  vetorFlags[idConta1-1] = 0;
  vetorFlags[idConta2-1] = 0;
  

  return 0;
}


void simular(int numAnos) {

  int i, saldoAnterior, saldoLido;
  int vetor[NUM_CONTAS];

  while (cont_ano <= numAnos) {

    printf("\nSIMULACAO: Ano %d\n=================\n", cont_ano);
      for (i = 1; i <= NUM_CONTAS; i++) {

        saldoLido = lerSaldo(i);

        if (cont_ano == 0) {
          printf("Conta %d, Saldo %d\n", i, saldoLido);
          vetor[i-1] = saldoLido;
        } 

        else if (saldoLido > 0) {
          saldoAnterior = saldoNovo(vetor[i-1]);
          printf("Conta %d, Saldo %d\n", i, saldoAnterior);
          vetor[i-1] = saldoAnterior;
        }

        else
          printf("Conta %d, Saldo %d\n", i, saldoLido);
      }
    
    printf("\n");

    if (flag == 0)
      cont_ano += 1;
      
    else 
      cont_ano = numAnos+1;
    
  }

}

int creditar2(int idConta, int idConta2, int valor) {
    
    if (!contaExiste(idConta) || !contaExiste(idConta2)) {
        return -1;
    }
    
    
    vetorFlags[idConta-1] = 1;
    vetorFlags[idConta2-1] = 1;
    
    atrasar();
    
    
    pthread_mutex_lock(&vetorMutex[idConta-1]);
    pthread_mutex_lock(&vetorMutex[idConta2-1]);
  
  
    contasSaldos[idConta - 1] += valor;
    contasSaldos[idConta2 - 1] += valor;
  
  
    pthread_mutex_unlock(&vetorMutex[idConta2-1]);
    pthread_mutex_unlock(&vetorMutex[idConta-1]);
  
    pthread_cond_broadcast(&condWait);
  
  
    vetorFlags[idConta-1] = 0;
    vetorFlags[idConta2-1] = 0;
  
    return 0;
}


/*----------------------------------------------------------------------------*/
/*---------------------------- FUNCOES AUXILIARES ----------------------------*/
/*----------------------------------------------------------------------------*/

int saldoNovo (int saldoAnterior) {
  return max(saldoAnterior * (1 + TAXAJURO) - CUSTOMANUTENCAO, 0);
}

void atualiza (int sig) {
    flag = 1;
}

int max(int valor1, int valor2) {
    if (valor1 >= valor2) return valor1;
    else
        return valor2;
}
