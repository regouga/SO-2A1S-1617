/*
// Projeto SO - exercicio 4, version 1
// Sistemas Operativos, DEI/IST/ULisboa 2016-17

// Grupo 71
// Miguel Regouga, 83530
// Pedro Caldeira, 83539
*/

/*####################################################################################################################*/
/* BIBLIOTECAS 																										  */
/*####################################################################################################################*/

#include "commandlinereader.h"
#include "contas.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <time.h>



/*####################################################################################################################*/
/* COMANDOS 																										  */
/*####################################################################################################################*/

#define COMANDO_DEBITAR "debitar"
#define COMANDO_CREDITAR "creditar"
#define COMANDO_LER_SALDO "lerSaldo"
#define COMANDO_SIMULAR "simular"
#define COMANDO_SAIR "sair"
#define COMANDO_SAIR_AGORA "agora"
#define COMANDO_TRANSFERIR "transferir"
#define COMANDO_SAIR_TERMINAL "sair-terminal"



/*####################################################################################################################*/
/* CONSTANTES 																										  */
/*####################################################################################################################*/

#define MAXARGS 4
#define BUFFER_SIZE 100
#define STATUS_INFO_LINE_SIZE 50
#define NUM_PROC 20
#define NUM_CONTAS 10



/*####################################################################################################################*/
/* PROCESSOS 																										  */
/*####################################################################################################################*/

int proc[NUM_PROC];
int proc_count = 0;
int argumentos = 0;



/*####################################################################################################################*/
/* TAREFAS E VETOR CIRCULAR 																						  */
/*####################################################################################################################*/

#define COMANDO_DEBITAR_NUM 1
#define COMANDO_CREDITAR_NUM 2
#define COMANDO_LER_SALDO_NUM 3
#define COMANDO_SAIR_NUM 4
#define COMANDO_TRANSFERIR_NUM 5
#define COMANDO_SIMULAR_NUM 6
#define COMANDO_SAIR_TERMINAL_NUM 7
#define COMANDO_SAIR_AGORA_NUM 8

#define NUM_TRABALHADORAS 3
#define CMD_BUFFER_DIM (NUM_TRABALHADORAS * 2) 

typedef struct {
    int operacao;
    int idConta;
    int idConta2;
    int valor;
} comando_t;

comando_t cmd_buffer[CMD_BUFFER_DIM];
int buff_write_idx = 0, buff_read_idx = 0;



/*####################################################################################################################*/
/* MAIN 																											  */
/*####################################################################################################################*/

int main (int argc, char** argv) {

    char *args[MAXARGS + 1];
    char buffer[BUFFER_SIZE];
    char bufferMsg[10000];
    
    int pipe, idConta, valor, idConta1, idConta2, pipe_rececao, msg_recebida;
    comando_t new;

    printf("Bem-vinda/o ao i-banco\n\n");
    
    /* ENVIO DO COMANDO */
    
    if ((pipe = open(argv[1], O_WRONLY)) < 0) exit(-1);


    
    /* RECECAO DA MENSAGEM */
    
    
    if ((mkfifo("/tmp/i-banco-rececao", 0777) < 0) && (errno != EEXIST)) 
    	perror ("Erro na criacao do pipe de rececao.\n");

    if ((pipe_rececao = open("/tmp/i-banco-rececao", O_RDONLY)) < 0) 
    	perror ("Erro no open do pipe de rececao.\n");



    while (1) {

        int numargs;
        numargs = readLineArguments(args, MAXARGS+1, buffer, BUFFER_SIZE);
        argumentos = numargs;


        /* EOF (end of file) do stdin ou comando "sair" */

        if (numargs < 0 ||
            (numargs > 0 && (strcmp(args[0], COMANDO_SAIR) == 0))) {

            new.operacao = COMANDO_SAIR_NUM;

        	if (numargs == 2 && (strcmp(args[1], COMANDO_SAIR_AGORA)) == 0)
        		new.valor = COMANDO_SAIR_AGORA_NUM;

        	else
        		new.valor = 0;

            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0)
            	perror("Erro na escrita do comando.");

        }
        
        /* Sair Terminal */

        else if (strcmp(args[0], COMANDO_SAIR_TERMINAL) == 0) {
            new.operacao = COMANDO_SAIR_TERMINAL_NUM;

            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");

            exit(0);
        }


        /* Nenhum argunento */
    
        else if (numargs == 0) continue;
            


        /* Debitar */

        else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_DEBITAR);
               continue;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);

            new.operacao = COMANDO_DEBITAR_NUM;
            new.idConta = idConta;
            new.valor = valor;
            
            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");
            

        }


        /* Creditar */

        else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {

            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_CREDITAR);
                continue;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);

            new.operacao = COMANDO_CREDITAR_NUM;
            new.idConta = idConta;
            new.valor = valor;
            
            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");

        }


        /* Ler Saldo */

        else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {

            if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_LER_SALDO);
                continue;
            }


            idConta = atoi(args[1]);

            new.operacao = COMANDO_LER_SALDO_NUM;
            new.idConta = idConta;
            new.valor = 0;
            
            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");

        }

        
        /* Transferir */

        else if (strcmp(args[0], COMANDO_TRANSFERIR) == 0) {

            if (numargs < 4) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_TRANSFERIR);
                continue;
            }
            
            if (atoi(args[1]) == atoi(args[2])) {
                printf("%s: ID das contas igual, tente de novo.\n", COMANDO_TRANSFERIR);
                continue;
            }

            idConta1 = atoi(args[1]);
            idConta2 = atoi(args[2]);
            valor = atoi(args[3]);

            new.operacao = COMANDO_TRANSFERIR_NUM;
            new.idConta = idConta1;
            new.idConta2 = idConta2;
            new.valor = valor;
            
            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");

        }


        /* Simular */

        else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {

        	if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_SIMULAR);
                continue;
            }

            valor = atoi(args[1]);

            new.operacao = COMANDO_SIMULAR_NUM;
            new.valor = valor;
            
            if (write(pipe, (void*)&new, sizeof(comando_t)) < 0) 
            	perror("Erro na escrita do comando.");

        }

        /* Comando Desconhecido */

        else {
          printf("Comando desconhecido. Tente de novo.\n");
          continue;
        }


        /* Rececao e impressao da mensagem */
        
        if ((msg_recebida = read(pipe_rececao, bufferMsg, sizeof(bufferMsg))) < 0) 
        	perror("Erro na leitura da mensagem.\n");

        printf("%s", bufferMsg);
        memset(bufferMsg, 0, strlen(bufferMsg));
        
    }

    close (pipe_rececao);
    close (pipe);

}
